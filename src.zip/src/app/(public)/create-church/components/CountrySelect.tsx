"use client";

import { useMemo } from "react";

// ISO 3166-1 alpha-2 country codes for worldwide coverage
// Curated list of 249 countries/territories
const COUNTRY_CODES = [
  "AF", "AX", "AL", "DZ", "AS", "AD", "AO", "AI", "AQ", "AG", "AR", "AM", "AW", "AU", "AT", "AZ",
  "BS", "BH", "BD", "BB", "BY", "BE", "BZ", "BJ", "BM", "BT", "BO", "BQ", "BA", "BW", "BV", "BR",
  "IO", "BN", "BG", "BF", "BI", "CV", "KH", "CM", "CA", "KY", "CF", "TD", "CL", "CN", "CX", "CC",
  "CO", "KM", "CG", "CD", "CK", "CR", "CI", "HR", "CU", "CW", "CY", "CZ", "DK", "DJ", "DM", "DO",
  "EC", "EG", "SV", "GQ", "ER", "EE", "SZ", "ET", "FK", "FO", "FJ", "FI", "FR", "GF", "PF", "TF",
  "GA", "GM", "GE", "DE", "GH", "GI", "GR", "GL", "GD", "GP", "GU", "GT", "GG", "GN", "GW", "GY",
  "HT", "HM", "VA", "HN", "HK", "HU", "IS", "IN", "ID", "IR", "IQ", "IE", "IM", "IL", "IT", "JM",
  "JP", "JE", "JO", "KZ", "KE", "KI", "KP", "KR", "KW", "KG", "LA", "LV", "LB", "LS", "LR", "LY",
  "LI", "LT", "LU", "MO", "MG", "MW", "MY", "MV", "ML", "MT", "MH", "MQ", "MR", "MU", "YT", "MX",
  "FM", "MD", "MC", "MN", "ME", "MS", "MA", "MZ", "MM", "NA", "NR", "NP", "NL", "NC", "NZ", "NI",
  "NE", "NG", "NU", "NF", "MK", "MP", "NO", "OM", "PK", "PW", "PS", "PA", "PG", "PY", "PE", "PH",
  "PN", "PL", "PT", "PR", "QA", "RE", "RO", "RU", "RW", "BL", "SH", "KN", "LC", "MF", "PM", "VC",
  "WS", "SM", "ST", "SA", "SN", "RS", "SC", "SL", "SG", "SX", "SK", "SI", "SB", "SO", "ZA", "GS",
  "SS", "ES", "LK", "SD", "SR", "SJ", "SE", "CH", "SY", "TW", "TJ", "TZ", "TH", "TL", "TG", "TK",
  "TO", "TT", "TN", "TR", "TM", "TC", "TV", "UG", "UA", "AE", "GB", "US", "UM", "UY", "UZ", "VU",
  "VE", "VN", "VG", "VI", "WF", "EH", "YE", "ZM", "ZW"
];

interface CountrySelectProps {
  id?: string;
  name: string;
  defaultValue?: string;
  required?: boolean;
  className?: string;
}

export function CountrySelect({ id, name, defaultValue, required, className }: CountrySelectProps) {
  const countries = useMemo(() => {
    // Use Intl.DisplayNames for localized country names when available
    let displayNames: Intl.DisplayNames | undefined;
    try {
      displayNames = new Intl.DisplayNames(typeof navigator !== "undefined" ? navigator.language : "en", {
        type: "region",
      });
    } catch {
      // Fallback if Intl.DisplayNames is not supported
    }

    const list = COUNTRY_CODES.map((code) => ({
      code,
      name: displayNames?.of(code) || code,
    }));

    // Sort by name
    return list.sort((a, b) => a.name.localeCompare(b.name));
  }, []);

  return (
    <select
      id={id}
      name={name}
      defaultValue={defaultValue}
      required={required}
      className={className}
    >
      <option value="">Select a country...</option>
      {countries.map((country) => (
        <option key={country.code} value={country.code}>
          {country.name}
        </option>
      ))}
    </select>
  );
}

// Helper to get country name from code
export function getCountryName(code: string): string {
  if (!code) return "";
  try {
    const displayNames = new Intl.DisplayNames(typeof navigator !== "undefined" ? navigator.language : "en", {
      type: "region",
    });
    return displayNames.of(code) || code;
  } catch {
    return code;
  }
}
