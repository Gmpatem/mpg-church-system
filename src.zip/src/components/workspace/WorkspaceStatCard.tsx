import { cn } from "@/lib/utils/cn";
import Link from "next/link";

interface WorkspaceStatCardProps {
  label: string;
  value: string | number;
  hint?: string;
  className?: string;
  valueClassName?: string;
  href?: string;
  icon?: React.ReactNode;
}

export function WorkspaceStatCard({
  label,
  value,
  hint,
  className,
  valueClassName,
  href,
  icon,
}: WorkspaceStatCardProps) {
  const content = (
    <>
      <div className="h-1 w-full bg-gradient-to-r from-blue-600 via-cyan-500 to-teal-500" />
      <div className="p-5">
        <div className="flex items-start justify-between">
          <p className="text-[11px] uppercase tracking-[0.18em] text-slate-500">
            {label}
          </p>
          {icon ? (
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-100 text-slate-600">
              {icon}
            </div>
          ) : null}
        </div>
        <p className={cn("mt-3 text-3xl font-bold tracking-tight text-slate-950", valueClassName)}>
          {typeof value === "number" ? value.toLocaleString("en-US") : value}
        </p>
        {hint ? (
          <p className="mt-2 text-xs text-slate-500">
            {hint}
          </p>
        ) : null}
      </div>
    </>
  );

  if (href) {
    return (
      <Link
        href={href}
        className={cn(
          "group overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md",
          className
        )}
      >
        {content}
      </Link>
    );
  }

  return (
    <div className={cn("overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm", className)}>
      {content}
    </div>
  );
}
